package com.shroomclient.shroomclientnextgen.mixin;

import net.minecraft.client.gui.DrawContext;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(DrawContext.class)
public abstract class DrawContextMixin {}
