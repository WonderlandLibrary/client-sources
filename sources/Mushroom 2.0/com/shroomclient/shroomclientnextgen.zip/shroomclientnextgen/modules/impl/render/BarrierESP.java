package com.shroomclient.shroomclientnextgen.modules.impl.render;

import com.shroomclient.shroomclientnextgen.modules.Module;
import com.shroomclient.shroomclientnextgen.modules.ModuleCategory;
import com.shroomclient.shroomclientnextgen.modules.RegisterModule;

@RegisterModule(
    name = "Visible Barriers",
    uniqueId = "barrieresp",
    description = "Makes Barriers Visible",
    category = ModuleCategory.Render,
    enabledByDefault = false
)
public class BarrierESP extends Module {

    // ugly ahh

    @Override
    protected void onEnable() {}

    @Override
    protected void onDisable() {}
}
