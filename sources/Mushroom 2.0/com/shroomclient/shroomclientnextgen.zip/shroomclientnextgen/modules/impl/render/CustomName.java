package com.shroomclient.shroomclientnextgen.modules.impl.render;

import com.shroomclient.shroomclientnextgen.modules.Module;
import com.shroomclient.shroomclientnextgen.modules.ModuleCategory;
import com.shroomclient.shroomclientnextgen.modules.RegisterModule;

@RegisterModule(
    name = "Nick Hider",
    uniqueId = "customname",
    description = "Changes Your Username (Client Sided)",
    category = ModuleCategory.Render
)
public class CustomName extends Module {

    // awesome sauce

    @Override
    protected void onEnable() {}

    @Override
    protected void onDisable() {}
}
