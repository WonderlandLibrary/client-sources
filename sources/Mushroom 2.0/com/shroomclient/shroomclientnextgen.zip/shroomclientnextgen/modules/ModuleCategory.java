package com.shroomclient.shroomclientnextgen.modules;

public enum ModuleCategory {
    Search,
    Combat,
    Render,
    Movement,
    Player,
    Client,
    Configs,
}
