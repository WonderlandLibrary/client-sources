package com.shroomclient.shroomclientnextgen.auth;

import javax.annotation.Nullable;
import net.minecraft.client.session.Session;

public class SessionManager {

    public static @Nullable Session sessionOverride = null;
}
